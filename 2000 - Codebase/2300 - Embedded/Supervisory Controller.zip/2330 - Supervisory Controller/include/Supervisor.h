#ifndef SUPERVISOR_H
#define SUPERVISOR_H

int deDuplicateCommandQueue(void);
int receiveMsg(void);
int processMsg(void);


#endif